#ifndef POINT_H
#define POINT_H


class Point
{
    public:
        Point(int d=2,int f=3);
       // Point();
    Point operator+=(const Point & a);
    Point operator+(const Point& a);
    Point operator=(const Point & a);
    bool operator==(Point & p);

      virtual ~Point();
        int getx() { return x; }
        void setx(int val) { x = val; }
        int gety() { return y; }
        void sety(int val) { y = val; }
        void Init(int a,int b);
        void Init(int a);
        void Deplacer(int a, int b);
        virtual void Affiche();
        void AfficheTout() ;
          void Affiche(char * message);
        int Coincide(Point & p);
   // protected:
    private:
        int x;
        int y;
};

#endif // POINT_H
