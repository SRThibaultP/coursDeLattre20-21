#include <iostream>
#include "point.h"
//#include "PointCol.h"

using namespace std;

int main()
{
    Point *p=new Point(5);
    p->Affiche();
    p->Deplacer(2,4);
    p->Affiche();
    Point *pp=new Point(7,7);

    pp->Affiche();

    if ((*pp)==(*p))
        cout<<"points identiques"<<endl;
    else cout <<"points differents"<<endl;;
    Point *p1=new Point();
    p1->Affiche();
    (*p1)=(*pp);
    p1->Affiche();
    (*p1)=(*pp)+(*p);
    pp->Affiche();
    p->Affiche();
    p1->Affiche();
    (*p1)+=(*p);
    p1->Affiche();


    return 0;
}
