#include <iostream>
#include "point.h"
using namespace std;
/*
Point::Point(){
   Init(0,0);
}
*/
Point::Point(int a,int b)
{

    Init(a,b);
}

Point::~Point()
{
    cout << "--destructeur --"<<endl;
}

Point Point::operator+=( const Point & a)
{
this->x = a.x + this->x;
this->y = a.y + this->y;
return *this;
}


Point Point::operator+( const Point & a)
{
Point p;
p.x = x + a.x;
p.y = y + a.y;
return p;
}


Point Point::operator=(const Point & a)
{

this->x=a.x;
this->sety(a.y);
//this->y=a.y ;
return *this;
}


void Point::Init(int a,int b){
         this->x=a;
         this->y=b;

    }

void Point::Init(int a){
         this->x=a;
         this->y=a;
    }


void Point::Deplacer(int a, int b){
            this->x+=a;
            this->y+=b;
    }

void Point::Affiche(){
    cout << this->x<<" , " <<this->y<< endl;
        }

void Point::AfficheTout()
{
cout << this << "->" << x << ", " << y << endl;
Affiche();
}

void Point::Affiche(char *message ){
    cout << message <<this->x<<" , " <<this->y<< endl;
        }

int Point::Coincide(Point & p){
    if ((p.getx()==this->x)&&(p.gety()==this->y))
        return 1;
    return 0;

}

bool Point::operator==(Point & p){
    if ((p.getx()!=this->x))  return false;
     if ((p.gety()!=this->y))  return false;
    return true;

}


